package Repo

import (
	"ReadFileProj/ice_cream"
	"bufio"
	json "encoding/json"
	"fmt"
	"io/ioutil"
	"os"
)
type DB struct {
	IceCreams []ice_cream.IceCream
}

func ConvertData() (DB, error) {
	data := DB{}
	byteData, err := ioutil.ReadFile("/home/heather/Downloads/ReadFileProj/icDB.json")
	if err != nil{
		fmt.Println(err)
	}
	err = json.Unmarshal(byteData, &data)
	if err != nil{
		fmt.Println(err)
	}
	return data, err
}

func ConvertBack (db DB) error{
	data, err := json.Marshal(db)
	if err !=nil {
		fmt.Println(err)
	}
	err = ioutil.WriteFile("/home/heather/Downloads/ReadFileProj/icDB.json", data, 0644)
	return nil
}


// Create a function that accepts an IceCream, converts it to JSON and stores it on the next available line in iceCreamDb.txt
// Return an error if any of the functions you call return an error
func CreateIceCream(ice ice_cream.IceCream) error {
	convData, _ := ConvertData()
	fmt.Println("this is before", convData)
	convData.IceCreams = append(convData.IceCreams, ice)
	fmt.Println("this is after", convData)

	convBack := ConvertBack(convData)
	return convBack
}

// Create function that can retrieve all the ice creams from iceCreamDb.txt
// The function should unmarshal each one into an ice cream struct and return a slice of IceCream --> []IceCream
// Return an error if any of the functions you call return an error
func GetAllIceCreams() ([]ice_cream.IceCream, error){
	file, err := os.Open("/home/heather/Downloads/ReadFileProj/icDB.json")

	if err != nil {
		fmt.Println(err)
	}

	scanner := bufio.NewScanner(file)
	scanner.Split(bufio.ScanLines)

	var iceSlice []string
	var iceCream []ice_cream.IceCream

	ic := ice_cream.IceCream{}

	for scanner.Scan(){
		iceSlice = append(iceSlice, scanner.Text())
	}

	for _, val := range iceSlice {
		_ = json.Unmarshal([]byte(val), &ic)
		iceCream = append(iceCream, ic)

	}
	return iceCream, err
}

func GetIceCreamByName(name string)(ice_cream.IceCream ,error){
	fName := &DB{"IceCreams":"Name"}


	name, err := ioutil.ReadFile("/home/heather/Downloads/ReadFileProj/icDB.json")
	if err != nil{
		fmt.Println(name)
	}

	return fName, err


}

func DeleteIceCreamByName(name string) error {


}